import io
import face_recognition.api as api

with open("faceauth2.jpeg", "rb") as f:
    img_bytes = io.BytesIO(f.read())
    img_array = api.load_image_file(img_bytes)

